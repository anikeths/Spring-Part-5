package com.rest.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestSpringBootCrudProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
